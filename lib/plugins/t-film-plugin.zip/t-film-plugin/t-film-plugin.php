<?php

/*
Plugin Name: T-Film (Plugin)
Plugin URI: 
Description: Phần plugin cho theme T-Film
Author: maruro
Version: 1.0.0
*/

class T_Film{

	private $omdbapi = "http://www.omdbapi.com/?apikey=8a3dc10f";

	function __construct(){
		
		define('T_FILM_PLUGIN', '1.0.0');

		register_activation_hook( __FILE__, [$this, 'active_plugin'] );

		add_action('init', [$this, 'load_textdomain']);
		add_action('init', [$this, 'register_film_post_type']);
		add_action('init', [$this, 'register_film_taxonomies']);

		add_action('admin_init', [ $this, 'customize_admin_page_film']);
		add_action('init', [$this, 'add_taxonomy_to_plugin'], 999);

		add_action('t-film-plugin-save-user-profile', [$this, 'save_user_profile']);
		add_action('t-film-plugin-save-user-film-data', [ $this, 'update_film_meta_front_page' ]);
		add_action('t-film-plugin-update-view-count', [$this, 'update_view_count']);
		add_action('pre_get_posts', [$this, 'config_wp_query'] );
		add_action('rest_api_init', [$this, 'create_api_user_meta_field']);

		add_action('admin_menu', [$this, 'create_menu_admin_page']);
		add_action('admin_init', [$this, 't_film_plugin_save_setting'] );
		add_action('admin_init', [$this, 't_film_plugin_import'] );

		$this->customize_film_manage_edit_page();

		//https://wordpress.stackexchange.com/questions/178484/wp-query-args-title-or-meta-value
		add_action( 'pre_get_posts', function( $q )
		{
		    if( $title = $q->get( '_meta_or_title' ) )
		    {
		        add_filter( 'get_meta_sql', function( $sql ) use ( $title )
		        {
		            global $wpdb;

		            // Only run once:
		            static $nr = 0; 
		            if( 0 != $nr++ ) return $sql;

		            // Modify WHERE part:
		            $sql['where'] = sprintf(
		                " AND ( %s OR %s ) ",
		                $wpdb->prepare( "{$wpdb->posts}.post_title like '%%%s%%'", $title ),
		                mb_substr( $sql['where'], 5, mb_strlen( $sql['where'] ) )
		            );
		            return $sql;
		        });
		    }
		});
	}

	public function create_menu_admin_page()
	{
		/*add_options_page( __('Cài đặt T-Film', 't-film-plugin'), 'T-Film', 'manage_options', 't-film-settings', function(){

				$options = get_option('t-film-plugin')['films-per-page'];

			?>
				<h3>T-Film</h3>

				<form action="admin-post.php" method="post">
					<?= __('Phim hiển thị trên trang chính:', 't-film-plugin') ?> <input type="number" class="small-text" name="fp[cover]" value="<?= $options['cover']?>"><br/>
					<?= __('Phim hiển thị trên list (dọc):', 't-film-plugin') ?> <input type="number" class="small-text" name="fp[list-y]" value="<?= $options['list-y']?>"><br/>
					<?= __('Phim hiển thị trên list (ngang):', 't-film-plugin')?> <input type="number" class="small-text" name="fp[list-x]" value="<?= $options['list-x']?>"><br/>
					<?= __('Phim hiển thị trên trang tìm kiếm:', 't-film-plugin')?> <input type="number" class="small-text" name="fp[search]" value="<?= $options['search']?>"><br/>
					<?php wp_nonce_field( 't-film-plugin' ) ?>
					<input type="hidden" name="action" value="t_film_plugin_save_setting" />
					<button class="button-primary" type="submit"><?= __('Lưu cài đặt', 't-film-plugin') ?></button>
				</form>

			<?php

		});*/

		add_menu_page( __('T-Film', 't-film-plugin'), 'T-Film', 'manage_options', 't-film-settings', function(){

				$options = get_option('t-film-plugin')['films-per-page'];

			?>
				<h3>T-Film</h3>

				<form action="admin-post.php" method="post">
					<?= __('Phim hiển thị trên trang chính:', 't-film-plugin') ?> <input type="number" class="small-text" name="fp[cover]" value="<?= $options['cover']?>"><br/>
					<?= __('Phim hiển thị trên list (dọc):', 't-film-plugin') ?> <input type="number" class="small-text" name="fp[list-y]" value="<?= $options['list-y']?>"><br/>
					<?= __('Phim hiển thị trên list (ngang):', 't-film-plugin')?> <input type="number" class="small-text" name="fp[list-x]" value="<?= $options['list-x']?>"><br/>
					<?= __('Phim hiển thị trên trang tìm kiếm:', 't-film-plugin')?> <input type="number" class="small-text" name="fp[search]" value="<?= $options['search']?>"><br/>
					<?php wp_nonce_field( 't-film-plugin' ) ?>
					<input type="hidden" name="action" value="t_film_plugin_save_setting" />
					<button class="button-primary" type="submit"><?= __('Lưu cài đặt', 't-film-plugin') ?></button>
				</form>

			<?php

		});

		add_submenu_page( 't-film-settings', 'Nhập', 'Nhập', 'manage_options', 't-film-import', function(){

			?>
				<style>
					table{
						table-layout: fixed; 
						width: 100%;
						border-collapse: collapse;
						margin-bottom: 5px;
					}

					table, tr, td, th{
						border: 1px solid black;
						text-align: left;
					}

					td,th{
						padding: 5px;
					}

					#wrap-table{
						padding: 10px;
						background: white;
					}

					img{
						height: 100px;
						width: auto;
					}

					#pagination{
						margin-bottom: 5px;
					}
				</style>

				<?php if(isset($_GET['message'])):?>
					<h4><?= $_GET['message']; ?></h4>
				<?php endif; ?>

				<h3>Nhập film</h3>
				<form method="get">
					<?= __('Nhập tên film cần tìm: ', 't-film-plugin') ?> <input type="text" name="keyword" value="<?= $_GET['keyword']?>"><br/>
					<input type="hidden" name="page" value="t-film-import" />
					<button class="button-primary" name="search" type="submit"><?= __('Tìm', 't-film-plugin') ?></button>
				<hr/>
				</form>

				<?php if(!empty($_GET['keyword'])): ?>

				<?php 

					$keyword = trim($_GET['keyword']);
					$page = $_GET['numpage'] ?: 1;
					$perPage = 10;
					$url = $this->omdbapi."&s=$keyword&page=$page";
					$res = wp_remote_get( $url);
					$res = json_decode(wp_remote_retrieve_body( $res ), true);
					$list = $res['Search'];

					$totalPage = ceil($res['totalResults'] / $perPage);
					echo "<h4>Có {$res['totalResults']} kết quả tìm thấy</h4>"
				?>

				<form method="get" id="pagination">
					<input type="hidden" name="page" value="t-film-import" />
					<input type="hidden" name="search" value="" />
					<input type="hidden" name="keyword" value="<?= $keyword ?>" />

					<?php for($i=1; $i<=$totalPage; ++$i): ?>
						<button class="button <?= $i == $page ? 'button-primary' : ''?>" name="numpage" value="<?= $i?>" type="submit"><?= $i ?></button>

					<?php endfor;?>

				</form>

				<form action="admin-post.php" method="post">
					<?php wp_nonce_field( 't-film-plugin' ) ?>
					<input type="hidden" name="action" value="t_film_plugin_import" />
					<div id="wrap-table">
						<table>
							<tr><th>Tên film</th><th>Hình thức</th><th>Năm</th><th>Poster</th><th>Thêm</th></tr>

							<?php foreach($list as $item): ?>
								<tr>
									<td><?= $item['Title']?></td>
									<td><?= $item['Type']?></td>
									<td><?= $item['Year']?></td>
									<td><img src="<?= $item['Poster']?>" alt="Poster <?= $item['Title']?>"/></td>
									<td><input type="checkbox" name="list[]" value="<?= $item['imdbID']?>" /></td>
								</tr>
							<?php endforeach; ?>
						</table>
						<button class="button-primary" name="import" type="submit"><?= __('Thêm', 't-film-plugin') ?></button>
					</div>
				</form>
				<?php endif;?>

			<?php

		});
	}

	public function t_film_plugin_save_setting()
	{
		add_action('admin_post_t_film_plugin_save_setting', function(){

			if(!current_user_can( 'manage_options' ))
				wp_die(__('Không được phép', 't-film-plugin'));

			check_admin_referer( 't-film-plugin' );

			$options = get_option('t-film-plugin');

			$options_fp = $options['films-per-page'];

			$options_fp = wp_parse_args( $_POST['fp'], $options_fp );

			$options['films-per-page'] = $options_fp;

			update_option('t-film-plugin', $options);

			wp_redirect( add_query_arg('page', 't-film-settings', admin_url( 'admin.php' )) );

			exit;
		});
	}

	//
	private function Generate_Featured_Image( $image_url, $post_id  ){
	    $upload_dir = wp_upload_dir();
	    $image_data = file_get_contents($image_url);
	    $filename = basename($image_url);
	    if(wp_mkdir_p($upload_dir['path']))     $file = $upload_dir['path'] . '/' . $filename;
	    else                                    $file = $upload_dir['basedir'] . '/' . $filename;
	    file_put_contents($file, $image_data);

	    $wp_filetype = wp_check_filetype($filename, null );
	    $attachment = array(
	        'post_mime_type' => $wp_filetype['type'],
	        'post_title' => sanitize_file_name($filename),
	        'post_content' => '',
	        'post_status' => 'inherit'
	    );
	    $attach_id = wp_insert_attachment( $attachment, $file, $post_id );
	    require_once(ABSPATH . 'wp-admin/includes/image.php');
	    $attach_data = wp_generate_attachment_metadata( $attach_id, $file );
	    $res1= wp_update_attachment_metadata( $attach_id, $attach_data );
	    $res2= set_post_thumbnail( $post_id, $attach_id );
	}

	public function t_film_plugin_import()
	{
		add_action('admin_post_t_film_plugin_import', function(){

			if(!current_user_can( 'manage_options' ))
				wp_die(__('Không được phép', 't-film-plugin'));

			check_admin_referer( 't-film-plugin' );

			if(empty($_POST['list']))
			{
				$message = "Chưa chọn film";
			}
			else
			{
				$list = $_POST['list'];
				foreach ($list as $item) {
					$res = wp_remote_get( $this->omdbapi."&i=$item");
					$body = wp_remote_retrieve_body( $res );
					$data = json_decode( $body, true );

					$film = wp_insert_post([

						'post_title' => $data['Title'],
						'post_content' => $data['Plot'],
						'post_status' => 'publish',
						'post_type' => 'film',
						'post_author' => get_current_user_id(),
						'tax_input' => [
							'film_actor' => explode(', ', $data['Actors']),
							'film_country' => explode(', ', $data['Country']),
							'film_director' => explode(', ', $data['Director']),
							'film_genre'=> explode(', ', $data['Genre'])
						]
					]);

					$date = date_format(date_create($data['Released']), 'd-m-Y');
					update_post_meta( $film, 'film_date', $date);
					update_post_meta( $film, 'film_series', $data['Type'] == 'movie' ? 0 : 1);
					update_post_meta( $film, 'film_quality', 'N/A');
					update_post_meta( $film, 'film_subtitle', 'N/A');
					update_post_meta( $film, 'film_runtime', str_replace(' min', '', $data['Runtime']));
					update_post_meta( $film, 'film_imdb', $data['imdbRating']);
					update_post_meta( $film, 'film_status', 1);

					$this->Generate_Featured_Image($data['Poster'], $film);
				}

				$message = esc_html('Đã thêm '.count($list). ' film mới');
			}

			wp_redirect( add_query_arg(['page'=>'t-film-import', 'message' => $message ], admin_url( 'admin.php' )) );

			exit;
		});
	}

	public function customize_film_manage_edit_page()
	{
		add_filter('manage_edit-film_columns', function($columns){

			$columns['poster'] = 'Poster';
			return $columns;

		});

		add_action('manage_posts_custom_column', function($column){

			switch ($column) {
				case 'poster':
					$img_url = get_the_post_thumbnail_url( get_the_ID() );
					echo "<img src='$img_url' height='150px' width='auto' />";
					break;
			}

		});
	}

	public function create_api_user_meta_field()
	{
		register_rest_field( 'user', 't-film-plugin-history', [
			'get_callback' => function( $params )
			{
				return get_user_meta( $params['id'], 't-film-plugin-history', $single = true );
			},
			'update_callback' => function($value, $user, $fieldName)
			{
				return update_user_meta( $user->ID, 't-film-plugin-history', $value);
			}
		] );
	}

	public function config_wp_query( $query ) {

		if($query->is_archive() && !$query->is_search())
		{
			$query->set('posts_per_page', '-1');
		}

	    if ( $query->is_tag() && isset($_GET['post_type']) && $_GET['post_type'] == 'film' ) {
	        $query->set( 'post_type', array('film' ) );
	    }

	    $query->set('post_status', [ 'publish' ]);
	}

	public function update_view_count()
	{
		if(current_user_can('edit_posts')) return;
			//update_view_count
		$view_count = get_post_meta( get_the_ID(), 'film_view_count', true );
		$view_count = $view_count ? $view_count : 0;
		update_post_meta( get_the_ID(), 'film_view_count', $view_count + 1);
	}

	public function update_film_meta_front_page(){

		if(is_user_logged_in() && isset($_POST['add-wishlist']))
		{
			$user_id = get_currentuserinfo()->ID;
			$wishlist = get_user_meta( $user_id, 't-film-plugin-wishlist', true);
			$wishlist = !empty($wishlist) ? $wishlist : [];

			if(!in_array(get_the_ID(), $wishlist))
			{
				$wishlist[] = get_the_ID();
				$msg = '2';
			}
			else
			{
				array_splice($wishlist, array_search(get_the_ID(), $wishlist), 1);
				$msg = '3';
			}

			update_user_meta( $user_id, 't-film-plugin-wishlist', $wishlist);
			wp_redirect( add_query_arg([
				'message' => $msg,

			], get_the_permalink() ));
		}

		//check rating
		if(isset($_POST['film-rating']))
		{
			$film_rating = get_post_meta(get_the_ID(), 'film_rating', true);
			$film_rating = $film_rating ? $film_rating : [];
			$film_rating[] = $_POST['film-rating'];
			update_post_meta( get_the_ID(), 'film_rating', $film_rating);

			wp_redirect( add_query_arg([
				'message' => '1',

			], get_the_permalink() ));
		}
		
	}

	private function check_add_page($title, $template = null){

		$page = get_page_by_title( $title );

		if(!$page)
		{
			$post_id = wp_insert_post( [
				'post_title' => $title,
				'post_type' => 'page',
				'post_status' => 'publish'
			] );

			update_post_meta( $post_id, '_wp_page_template', $template );
		}
	}

	public function active_plugin(){

		$this->check_add_page(__('Thông tin tài khoản', 't-film-plugin'), 'user-info.php');

		$this->register_film_post_type();
		$this->register_film_taxonomies();

		add_option( 't-film-plugin', [
			'film-series' => [ __('Phim lẻ', 't-film-plugin'), __('Phim bộ', 't-film-plugin') ],
			'film-status'=> [__('Hoàn tất', 't-film-plugin'), __('Chưa hoàn tất', 't-film-plugin'), __('Trailer', 't-film-plugin')],
			'alert-messages' => [
						__('Bạn đã đánh giá phim', 't-film-plugin'),
						__('Đã thêm phim vào danh sách yêu thích', 't-film-plugin'),
						__('Đã xoá phim trong danh sách yêu thích', 't-film-plugin')
					],
			'films-per-page' => [
				'cover' => 15,
				'list-x' => 20,
				'list-y' => 15,
				'search' => 20
			]
		] );

		register_meta( 'user', 't-film-plugin-wishlist', [
			'type' => 'string',
			'single' => false
		]);

		register_meta( 'user', 't-film-plugin-history', [
			'type' => 'string',
			'single' => true
		]);

		flush_rewrite_rules();
	}



	public function load_textdomain()
	{
		load_plugin_textdomain( 't-film-plugin', FALSE, dirname(plugin_basename( __FILE__ )).'/languages' );
	}

	public function register_film_post_type(){

		$labels = array(
				'name'               => __( 'Phim', 't-film-plugin' ),
				'singular_name'      => __( 'Phim', 't-film-plugin' ),
				'add_new'            => _x( 'Thêm phim mới', 't-film-plugin', 't-film-plugin' ),
				'add_new_item'       => __( 'Thêm phim mới', 't-film-plugin' ),
				'edit_item'          => __( 'Chỉnh sửa phim', 't-film-plugin' ),
				'new_item'           => __( 'Phim mới', 't-film-plugin' ),
				'view_item'          => __( 'Xem phim', 't-film-plugin' ),
				'search_items'       => __( 'Tìm kiếm phim', 't-film-plugin' ),
				'not_found'          => __( 'Không có phim', 't-film-plugin' ),
				'not_found_in_trash' => __( 'Không có phim bị xoá', 't-film-plugin' ),
				'parent_item_colon'  => __( 'Phim cha:', 't-film-plugin' ),
				'menu_name'          => __( 'Danh sách phim', 't-film-plugin' ),
			);
		
			$args = array(
				'labels'              => $labels,
				'hierarchical'        => false,
				'description'         => 'description',
				'taxonomies'          => array(),
				'public'              => true,
				'show_ui'             => true,
				'show_in_menu'        => true,
				'show_in_admin_bar'   => true,
				'menu_position'       => 5,
				'menu_icon'           => 'dashicons-playlist-video',
				'show_in_nav_menus'   => true,
				'publicly_queryable'  => true,
				'exclude_from_search' => false,
				'has_archive'         => true,
				'query_var'           => true,
				'can_export'          => true,
				'rewrite'             => [ 'slug' => 'film' ],
				'supports'            => array(
					'title',
					'editor',
					'author',
					'thumbnail',
					'excerpt',
					'comments',
					'revisions'
				),
			);
		
			register_post_type( 'film', $args );

			register_taxonomy_for_object_type( 'post_tag', 'film' );
	}

	public function register_film_taxonomies(){

		$labels = array(
			'name'                  => _x( 'Diễn viên phim', 'Taxonomy plural name', 't-film-plugin' ),
			'singular_name'         => _x( 'Diễn viên phim', 'Taxonomy singular name', 't-film-plugin' ),
			'search_items'          => __( 'Tìm kiếm diễn viên phim', 't-film-plugin' ),
			'popular_items'         => __( 'Diễn viên nổi tiếng', 't-film-plugin' ),
			'all_items'             => __( 'Tất cả các diễn viên', 't-film-plugin' ),
			'parent_item'           => __( 'Diễn viên', 't-film-plugin' ),
			'parent_item_colon'     => __( 'Diễn viên', 't-film-plugin' ),
			'edit_item'             => __( 'Chỉnh sửa diễn viên phim', 't-film-plugin' ),
			'update_item'           => __( 'Cập nhật diễn viên phim', 't-film-plugin' ),
			'add_new_item'          => __( 'Thêm mới diễn viên phim', 't-film-plugin' ),
			'new_item_name'         => __( 'Diễn viên phim mới', 't-film-plugin' ),
			'add_or_remove_items'   => __( 'Thêm hoặc xoá diễn viên phim', 't-film-plugin' ),
			'choose_from_most_used' => __( 'Chọn diễn viên phim', 't-film-plugin' ),
			'menu_name'             => __( 'Diễn viên phim', 't-film-plugin' ),
		);

		$args = array(
			'labels'            => $labels,
			'public'            => true,
			'show_in_nav_menus' => true,
			'show_admin_column' => false,
			'hierarchical'      => false,
			'show_tagcloud'     => true,
			'show_ui'           => true,
			'query_var'         => true,
			'rewrite'           => [ 'slug' => 'actor' ],
			'query_var'         => true,
			'capabilities'      => array('manage_terms', 'edit_terms', 'delete_terms', 'assign_terms')
		);

		register_taxonomy( 'film_actor', 'film', $args );

		$labels = array(
			'name'                  => _x( 'Quốc gia', 'Taxonomy plural name', 't-film-plugin' ),
			'singular_name'         => _x( 'Quốc gia', 'Taxonomy singular name', 't-film-plugin' ),
			'search_items'          => __( 'Tìm kiếm quốc gia phim', 't-film-plugin' ),
			'popular_items'         => __( 'Quốc gia phổ biến', 't-film-plugin' ),
			'all_items'             => __( 'Tất cả các quốc gia', 't-film-plugin' ),
			'parent_item'           => __( 'Quốc gia', 't-film-plugin' ),
			'parent_item_colon'     => __( 'Quốc gia', 't-film-plugin' ),
			'edit_item'             => __( 'Chỉnh sửa quốc gia', 't-film-plugin' ),
			'update_item'           => __( 'Cập nhật quốc gia', 't-film-plugin' ),
			'add_new_item'          => __( 'Thêm mới quốc gia', 't-film-plugin' ),
			'new_item_name'         => __( 'Quốc gia mới', 't-film-plugin' ),
			'add_or_remove_items'   => __( 'Thêm hoặc xoá quốc gia', 't-film-plugin' ),
			'choose_from_most_used' => __( 'Chọn quốc gia phim', 't-film-plugin' ),
			'menu_name'             => __( 'Quốc gia phim', 't-film-plugin' ),
		);

		$args = array(
			'labels'            => $labels,
			'public'            => true,
			'show_in_nav_menus' => true,
			'show_admin_column' => false,
			'hierarchical'      => false,
			'show_tagcloud'     => true,
			'show_ui'           => true,
			'query_var'         => true,
			'rewrite'           => [ 'slug' => 'country' ],
			'query_var'         => true,
			'capabilities'      => array('manage_terms', 'edit_terms', 'delete_terms', 'assign_terms')
		);

		register_taxonomy( 'film_country', 'film', $args );

		$labels = array(
			'name'                  => _x( 'Đạo diễn phim', 'Taxonomy plural name', 't-film-plugin' ),
			'singular_name'         => _x( 'Đạo diễn phim', 'Taxonomy singular name', 't-film-plugin' ),
			'search_items'          => __( 'Tìm kiếm đạo diễn phim', 't-film-plugin' ),
			'popular_items'         => __( 'Đạo diễn nổi tiếng', 't-film-plugin' ),
			'all_items'             => __( 'Tất cả các đạo diễn', 't-film-plugin' ),
			'parent_item'           => __( 'Đạo diễn', 't-film-plugin' ),
			'parent_item_colon'     => __( 'Đạo diễn', 't-film-plugin' ),
			'edit_item'             => __( 'Chỉnh sửa đạo diễn phim', 't-film-plugin' ),
			'update_item'           => __( 'Cập nhật đạo diễn phim', 't-film-plugin' ),
			'add_new_item'          => __( 'Thêm mới đạo diễn phim', 't-film-plugin' ),
			'new_item_name'         => __( 'Đạo diễn mới', 't-film-plugin' ),
			'add_or_remove_items'   => __( 'Thêm, xoá đạo diễn', 't-film-plugin' ),
			'choose_from_most_used' => __( 'Chọn đạo diễn phim', 't-film-plugin' ),
			'menu_name'             => __( 'Đạo diễn phim', 't-film-plugin' ),
		);

		$args = array(
			'labels'            => $labels,
			'public'            => true,
			'show_in_nav_menus' => true,
			'show_admin_column' => false,
			'hierarchical'      => false,
			'show_tagcloud'     => true,
			'show_ui'           => true,
			'query_var'         => true,
			'rewrite'           => ['slug' => 'director'],
			'query_var'         => true,
			'capabilities'      => array('manage_terms', 'edit_terms', 'delete_terms', 'assign_terms')
		);

		register_taxonomy( 'film_director', 'film', $args );

		$labels = array(
			'name'                  => _x( 'Thể loại phim', 'Taxonomy plural name', 't-film-plugin' ),
			'singular_name'         => _x( 'Thể loại phim', 'Taxonomy singular name', 't-film-plugin' ),
			'search_items'          => __( 'Tìm kiếm thể loại phim', 't-film-plugin' ),
			'popular_items'         => __( 'Thể loại phim phổ biến', 't-film-plugin' ),
			'all_items'             => __( 'Tất cả các thể loại phim', 't-film-plugin' ),
			'parent_item'           => __( 'Thể loại phim cha', 't-film-plugin' ),
			'parent_item_colon'     => __( 'Thể loại phim cha', 't-film-plugin' ),
			'edit_item'             => __( 'Chỉnh sửa thể loại phim', 't-film-plugin' ),
			'update_item'           => __( 'Cập nhật thể loại phim', 't-film-plugin' ),
			'add_new_item'          => __( 'Thêm mới thể loại phim', 't-film-plugin' ),
			'new_item_name'         => __( 'Thể loại phim mới', 't-film-plugin' ),
			'add_or_remove_items'   => __( 'Thêm xoá thể loại phim', 't-film-plugin' ),
			'choose_from_most_used' => __( 'Chọn thể loại phim', 't-film-plugin' ),
			'menu_name'             => __( 'Thể loại phim', 't-film-plugin' ),
		);

		$args = array(
			'labels'            => $labels,
			'public'            => true,
			'show_in_nav_menus' => true,
			'show_admin_column' => true,
			'hierarchical'      => false,
			'show_tagcloud'     => true,
			'show_ui'           => true,
			'query_var'         => true,
			'rewrite'           => ['slug' => 'genre'],
			'query_var'         => true,
			'capabilities'      => array('manage_terms', 'edit_terms', 'delete_terms', 'assign_terms')
		);

		register_taxonomy( 'film_genre', 'film', $args );

	}

	public function add_taxonomy_to_plugin()
	{
		//add taxonomy to taxonomy_image_plugin
		if(!function_exists('get_wp_term_image'))
			return;

		$options = get_option('aft_options');
		$options['checked_taxonomies'] = ['film_actor' => 'film_actor'];
		update_option( 'aft_options', $options);
	}

	private function render_input_select($data, $name, $selectedValue)
	{
		echo "<select name='$name'>";
		echo '<option value="">Lựa chọn</option>';
		foreach($data as $index => $value)
		{
			printf('<option value="%d" %s>%s</option>', $index, $selectedValue == $index ? 'selected' : '', $value);
		}
		echo "</select>";
	}

	public function render_film_info_section($film)
	{
		$film_date = get_post_meta( $film->ID, 'film_date', true);
		$film_series = get_post_meta($film->ID, 'film_series', true);
		$film_status = get_post_meta( $film->ID, 'film_status', true);
		$film_quality = get_post_meta( $film->ID, 'film_quality', true);
		$film_subtitle = esc_html(get_post_meta($film->ID, 'film_subtitle', true));
		$film_trailer = esc_url(get_post_meta($film->ID, 'film_trailer', true));
		$film_banner = esc_url(get_post_meta($film->ID, 'film_banner', true));
		$film_episode_count = esc_html(get_post_meta($film->ID, 'film_episode_count', true));
		$film_featured = get_post_meta($film->ID, 'film_featured', true);
		$film_runtime = get_post_meta($film->ID, 'film_runtime', true);
		$film_imdb = get_post_meta($film->ID, 'film_imdb', true);
		$film_title_other = esc_html(get_post_meta($film->ID, 'film_title_other', true));

		$series = get_option('t-film-plugin')['film-series'];
		$status = get_option('t-film-plugin')['film-status'];
		?>
			<table style="table-layout: fixed; width: 100%">
				<tr id="film_series">
					<td style="width: 150px"><?= __('Đặt vào mục NỔI BẬT:', 't-film-plugin') ?> </td>
					<td>
						<input type="checkbox" name="film_featured" <?= $film_featured ? 'checked' : '' ?>/>
					</td>
				</tr>
				<tr id="film_series">
					<td><?= __('Hình thức:', 't-film-plugin')?> </td>
					<td>
						<?php $this->render_input_select($series, 'film_series', $film_series) ?>
					</td>
				</tr>
				<tr id="film_subtitle">
					<td><?= __('Tên khác:', 't-film-plugin')?> </td>
					<td>
						<input type="text" name="film_title_other" value="<?= $film_title_other ?>" placeholder='<?= __("Nhập tên phim", 't-film-plugin')?>' style="width: 100%"/>
					</td>
				</tr>
				<tr id="film_subtitle">
					<td><?= __('Banner:', 't-film-plugin') ?></td>
					<td>
						<input type="text" name="film_banner" value="<?= $film_banner ?>" placeholder="<?= __("Nhập đường link", 't-film-plugin') ?>" pattern="^(http:\/\/www\.|https:\/\/www\.|http:\/\/|https:\/\/)?[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,5}(:[0-9]{1,5})?(\/.*)?$" title="'<?= __("Link không hợp lệ", 't-film-plugin') ?>'" style="width: 100%"/>
						<?= $film_banner ? '<br/><img width="300px" height="auto" src="'.$film_banner.'"/>' : '' ?> 
						<br/><button type="button" style="margin-top: 5px" class="button" id="add-banner">Chèn banner</button>
						<script>
							$().ready(function(e){

								$('#add-banner').click(function(){

									if ( typeof wp !== 'undefined' && wp.media && wp.media.editor) {

										var input = $(this).prev().prev();
										var text = input.text();
						            
						                wp.media.editor.send.attachment = function(props, attachment) {
						                    input.val(attachment.url);
						                };

						                wp.media.editor.open($(this));
							        }

								});

							});
						</script>
					</td>
				</tr>
				<tr id="film_status">
					<td><?= __('Tình trạng phim:', 't-film-plugin')?> </td>
					<td>
						<?php $this->render_input_select($status, 'film_status', $film_status) ?>
					</td>
				</tr>
				<tr id="film_quality">
					<td><?= __('Chất lượng phim:', 't-film-plugin')?></td>
					<td>
						<input type="text" name="film_quality" value="<?= $film_quality ?>" placeholder='<?= __("Nhập chất lượng", 't-film-plugin') ?>'/>
					</td>
				</tr>
				<tr id="film_subtitle">
					<td><?= __('Phụ đề phim:','t-film-plugin')?> </td>
					<td>
						<input type="text" name="film_subtitle" value="<?= $film_subtitle ?>" placeholder='<?= __("Nhập phụ đề", 't-film-plugin') ?>'/>
					</td>
				</tr>
				<tr id="film_date">
					<td><?= __('Ngày ra mắt phim:', 't-film-plugin')?> </td>
					<td>
						<input name="film_date" value="<?= $film_date ?>" placeholder='<?= __("Nhập thời gian ra mắt", 't-film-plugin') ?>' type="date"/>
					</td>
				</tr>
				<tr id="film_trailer">
					<td><?= __('Trailer:', 't-film-plugin') ?> </td>
					<td>
						<input type="text" name="film_trailer" value="<?= $film_trailer ?>" placeholder="<?= __("Nhập đường link", 't-film-plugin') ?>" pattern="^(http:\/\/www\.|https:\/\/www\.|http:\/\/|https:\/\/)?[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,5}(:[0-9]{1,5})?(\/.*)?$" title="'<?= __("Link không hợp lệ", 't-film-plugin') ?>'" style="width: 100%"/>
						<button type="button" class="button" style="margin-top: 5px" id="add-trailer">Chèn trailer</button>
						<script>
							$().ready(function(e){

								$('#add-trailer').click(function(){

									if ( typeof wp !== 'undefined' && wp.media && wp.media.editor) {

										var input = $(this).prev();
										var text = input.text();
						            
						                wp.media.editor.send.attachment = function(props, attachment) {
						                    input.val(attachment.url);
						                };

						                wp.media.editor.open($(this));
							        }

								});

							});
						</script>
					</td>
				</tr>
				<tr id="film_runtime">
					<td><?= __('Thời lượng phim (phút):', 't-film-plugin')?> </td>
					<td>
						<input type="number" name="film_runtime" step="0.1" value="<?= $film_runtime ?>" placeholder='<?= __("Nhập thời lượng", 't-film-plugin') ?>'>
				</tr>
				<tr id="film_imdb">
					<td><?= __('Điểm IMDB:', 't-film-plugin') ?> </td>
					<td>
						<input type="number" name="film_imdb" step="0.1" value="<?= $film_imdb ?>" placeholder='<?= __("Nhập điểm IMDB", 't-film-plugin') ?>'>
				</tr>
				<tr id="film_episode_count">
					<td><?= __('Số tập phim:', 't-film-plugin') ?> </td>
					<td>
						<input name="film_episode_count" value="<?= $film_episode_count ?>" placeholder='<?= __("Nhập số tập", 't-film-plugin') ?>' type="text"/>
					</td>
				</tr>
			</table>

		<?php
	}

	private function update_film_info_from_data($film_ID, $key)
	{

		if(!current_user_can('edit_posts'))
			wp_die(__('Không được phép', 't-film-plugin'));

		if(isset($_POST[$key]) && $_POST[$key] != '')
		{
			$value = $_POST[$key];
			update_post_meta( $film_ID, $key, $value );
			return;
		}

		update_post_meta($film_ID, $key, '');
	}

	public function save_film_info_section($film_ID)
	{

		if(!current_user_can('edit_posts'))
			wp_die(__('Không được phép', 't-film-plugin'));

		if(get_post_type( $film_ID ) != 'film') return;

		$this->update_film_info_from_data($film_ID, 'film_date');
		$this->update_film_info_from_data($film_ID, 'film_series');
		$this->update_film_info_from_data($film_ID, 'film_status');
		$this->update_film_info_from_data($film_ID, 'film_quality');
		$this->update_film_info_from_data($film_ID, 'film_subtitle');
		$this->update_film_info_from_data($film_ID, 'film_trailer');
		$this->update_film_info_from_data($film_ID, 'film_banner');
		$this->update_film_info_from_data($film_ID, 'film_episode_count'); 	
		$this->update_film_info_from_data($film_ID, 'film_featured'); 
		$this->update_film_info_from_data($film_ID, 'film_runtime');
		$this->update_film_info_from_data($film_ID, 'film_imdb'); 
		$this->update_film_info_from_data($film_ID, 'film_title_other');

		//init film_view_count
		$view_count = get_post_meta( $film_ID, 'film_view_count', true );
		if(!$view_count)
			update_post_meta( $film_ID, 'film_view_count', 0);
		$film_rating = get_post_meta($film_ID, 'film_rating', true);
		if(!$film_rating)
			update_post_meta($film_ID, 'film_rating', []);
	}

	public function render_film_link_section($film)
	{

		$film_link = get_post_meta($film->ID, 'film_link', true);

		if(!is_array($film_link))
			$film_link = [];

		$link_tr = '<div class="%s" style="margin: 5px">'.
			'<div style="margin-bottom: 5px"><input type="text" name="film_link_name[]" value="%s" placeholder="'.__("Nhập tên phần", 't-film').'" /></div>'.
			'<div style="margin-bottom: 5px"><textarea rows="4" cols="82" name="film_link[]" placeholder="Nhập link phim (Link|Chất lượng|Ext|Default)">%s</textarea><button class="add-media button" style="margin-left: 5px" type="button">'.__('Chèn link', 't-film').'</button></div>'.
			'<div style="margin-bottom: 10px"><textarea rows="4" cols="82" name="film_link_subtitle[]" placeholder="Nhập link sub (Link|Tên sub)">%s</textarea><button class="add-subtitle button" style="margin-left: 5px" type="button">'.__('Chèn subtitle', 't-film').'</button></div>'.
			'<div><button class="remove-link button" style="color:#a00">Xoá</button></div>'.
			'<hr/>'.
		'</div>';

		?>
			<button class="button add-link button-primary" style="margin-bottom: 10px">Thêm video</button>
			<hr/>

		<?php

			foreach($film_link as $link)
			{
				printf($link_tr, 'link-div', esc_html($link['name']), esc_html($link['link']), esc_html($link['subtitle']));
			}

			printf($link_tr, 'link-div', '', '', '');

		?>
			</table>

			<script>
				$().ready(function(){

					var add_link = $('.link-div:last-child').html();

					function remove_tr(e){
						e.preventDefault();
						$(e.target).parent().parent().remove();
					}

					function add_media(button)
					{
						if ( typeof wp !== 'undefined' && wp.media && wp.media.editor) {

							var input = $(button).prev();
							var text = input.text();
							text += text == '' ? '' : '\n'; 
			            
			                wp.media.editor.send.attachment = function(props, attachment) {
			                    input.text(text + attachment.url);
			                };

			                wp.media.editor.open($(button));
				        }
					}

					function add_subtitle(button)
					{
						if ( typeof wp !== 'undefined' && wp.media && wp.media.editor) {

							var input = $(button).prev();
							var text = input.text();
							text += text == '' ? '' : '\n';
			            
			                wp.media.editor.send.attachment = function(props, attachment) {
			                    input.text(text + attachment.url + '|' + attachment.name);
			                };

			                wp.media.editor.open($(button));
				        }
					}

					$('.add-media').on('click', function(){
						add_media(this);
					});

					$('.add-subtitle').on('click', function(){
						add_subtitle(this);
					});

					$('.add-link').click(function(e){

						e.preventDefault();
						$('#film-link-table').append('<div class="link-div">' + add_link + '</div>');
						$('.remove-link:last-child').click(function(e){
							remove_tr(e);
						});
						$('.add-media:last-child').click(function(){
							add_media(this);
						})
						$('.add-subtitle:last-child').click(function(){
							add_subtitle(this);
						})

					});

					$('.remove-link').click(function(e){
						remove_tr(e);
					});

				});
			</script>

		<?php
	}

	public function save_film_link_section($film_ID)
	{
		if(get_post_type( $film_ID ) != 'film') return;

		if(!isset($_POST['film_link']))
			return;

		$film_link_name = $_POST['film_link_name'];
		$film_link = $_POST['film_link'];
		$film_link_subtitle = $_POST['film_link_subtitle'];

		$data_save = [];

		foreach($film_link as $index => $value)
		{
			if(!empty($value) && !empty($film_link_name[$index]))
			{
				$data_save[] = [
					'name' => $film_link_name[$index],
					'link' => $value,
					'subtitle' => $film_link_subtitle[$index]
				];
			}
		}

		if(count($data_save) == 0)
			update_post_meta( $film_ID, 'film_link', '' );
		else	
			update_post_meta( $film_ID, 'film_link', $data_save );
	}

	public function customize_admin_page_film()
	{
		add_meta_box( 'film-info', __('Thông tin phim', 't-film-plugin'), [$this, 'render_film_info_section'], 'film', 'normal', 'high');
		add_action('save_post_film', [ $this, 'save_film_info_section' ]);

		add_meta_box( 'film-link', __('Link phim', 't-film-plugin'), [$this, 'render_film_link_section'], 'film', 'normal', 'high');
		add_action('save_post_film', [ $this, 'save_film_link_section' ]);

		add_action('admin_enqueue_scripts', function(){

			wp_enqueue_media();

		});
	}

	public function save_user_profile()
	{
		if(!is_user_logged_in()) return;

		$user = get_currentuserinfo();

		if(!empty($_POST['password']))
		{
			if(empty($_POST['old_password']))
			{
				$msg = sprintf("<h6 class='text-danger'>%s</h6>", __('Bạn chưa nhập mật khẩu cũ', 't-film-plugin'));
				return;
			}

			if($_POST['password'] != $_POST['re_password'])
			{
				$msg = sprintf("<h6 class='text-danger'>%s</h6>", __('Mật khẩu nhập lại không khớp', 't-film-plugin'));
				return;
			}

			if(!wp_check_password( $_POST['old_password'], $user->data->user_pass, $user->data->ID ))
			{
				$msg = sprintf("<h6 class='text-danger'>%s</h6>", __('Bạn nhập mật khẩu cũ chưa đúng', 't-film-plugin'));
				return;
			}

			wp_set_password($_POST['password'], $user->data->ID );
		}

		wp_update_user( [
			'ID' => $user->data->ID,
			'display_name' => esc_html($_POST['display_name'])
		] );

		wp_set_auth_cookie($user->ID);
		wp_set_current_user($user->ID);
		do_action('wp_login', $user->user_login, $user);

		$msg = sprintf("<h6>%s</h6>", __('Đã cập nhật thông tin', 't-film-plugin'));

		echo $msg;
	}
}

new T_Film;