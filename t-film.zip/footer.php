	</div>
</div>

<footer>
	<div class="container-fluid">
		<div class="row p-3">
			<?php dynamic_sidebar( 'widget-footer-1' ); ?>
		</div>
		<div class="row text-center">
			<div class="col m-2">
				<h3>T-Film</h3>
			</div>
		</div>
	</div>
</footer>

<?php wp_footer(); ?>

</body>
</html>

<?php ob_flush(); ?>